import Calendar from "./component/calendar";

function App() {
  return (
    <div className="App">
      <Calendar date={"12/12/2011"}/>
    </div>
  );
}

export default App;
